#include <stdio.h>
#include <string.h>

char buf2[100];

int main(void)
{
    setvbuf(stdout, 0LL, 2, 0LL);
    setvbuf(stdin, 0LL, 1, 0LL);

    char buf[100];

    puts("welcome to NKCTF!");
    puts("u can make it in 5 min!");
    gets(buf);
    strncpy(buf2, buf, 100);
    puts("good luck!");

    return 0;
}
//gcc ret2shellcode.c -fno-stack-protector -o ret2shellcode -m32 -mpreferred-stack-boundary=4 -no-pie
